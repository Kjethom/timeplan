# Timeregnskap – prosjektoppgave

S-diagram og timeføring for prosjektoppgaven (7,5 sp). Planlagt kumulativ
innsats vises som referansekurve, førte timer som målt kurve, og differansen
mellom dem som avvik.

## Kjøre lokalt

```bash
npm install
npm run dev
```

## Publisere på GitHub Pages

1. Lag et nytt, tomt repo på GitHub. Kall det `timeplan` – heter det noe
   annet, endre `REPO_NAVN` øverst i `vite.config.js` tilsvarende.
2. Push koden:

   ```bash
   git init
   git add .
   git commit -m "Timeregnskap for prosjektoppgaven"
   git branch -M main
   git remote add origin https://github.com/BRUKERNAVN/timeplan.git
   git push -u origin main
   ```

3. I repoet: **Settings → Pages → Build and deployment → Source: GitHub Actions**.
4. Neste push bygger og publiserer automatisk. Siden havner på
   `https://BRUKERNAVN.github.io/timeplan/`.

## Om lagringen

Timene lagres i nettleserens `localStorage`, ikke i repoet. Det betyr at data
er knyttet til én nettleser på én enhet – fører du timer på mobilen, ser du
dem ikke på laptopen. Bruk «Last ned CSV» hvis du vil ha en kopi utenfor
nettleseren.

Repoet inneholder ingen timedata, så det kan trygt være offentlig. GitHub
Pages krever offentlig repo på gratisplanen.
