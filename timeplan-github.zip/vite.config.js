import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { defineConfig } from 'vite'

// Bytt REPO_NAVN hvis du kaller GitHub-repoet noe annet enn "timeplan".
// GitHub Pages serverer siden fra https://<brukernavn>.github.io/REPO_NAVN/,
// så byggingen må vite om undermappa. Dev-serveren kjører på rot.
const REPO_NAVN = 'timeplan'

export default defineConfig(({ command }) => ({
  base: command === 'build' ? `/${REPO_NAVN}/` : '/',
  plugins: [react(), tailwindcss()],
}))
